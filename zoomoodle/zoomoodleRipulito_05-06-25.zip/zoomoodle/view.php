<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Pagina principale del modulo Zoomoodle
 * 
 * Questa pagina gestisce la visualizzazione dei dettagli del meeting Zoom
 * e fornisce l'interfaccia per partecipare al meeting
 * 
 * @package   mod_zoomoodle
 * @copyright 2023 Your Name <your@email.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once('../../config.php');
require_once($CFG->dirroot . '/mod/zoomoodle/lib.php');

// Recupera i parametri dalla richiesta
$id = required_param('id', PARAM_INT); // Course Module ID

// Recupera il course module
$cm = get_coursemodule_from_id('zoomoodle', $id, 0, false, MUST_EXIST);
$course = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);
$moduleinstance = $DB->get_record('zoomoodle', array('id' => $cm->instance), '*', MUST_EXIST);

// Richiede il login e verifica l'accesso al corso
require_login($course, true, $cm);
$modulecontext = context_module::instance($cm->id);
require_capability('mod/zoomoodle:view', $modulecontext);

// Imposta le variabili della pagina
$PAGE->set_url('/mod/zoomoodle/view.php', array('id' => $cm->id));
$PAGE->set_title(format_string($moduleinstance->name));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_context($modulecontext);

// Marca il modulo come visualizzato per il completamento
$completion = new completion_info($course);
$completion->set_module_viewed($cm);

// Inizializza l'output
echo $OUTPUT->header();

// Mostra il titolo del meeting
echo $OUTPUT->heading(format_string($moduleinstance->name));

// Mostra la descrizione se presente
if (!empty($moduleinstance->intro)) {
    echo $OUTPUT->box(format_module_intro('zoomoodle', $moduleinstance, $cm->id), 'generalbox mod_introbox', 'zoommodleintro');
}

// Recupera i dettagli del meeting da Zoom
try {
    $api = new \mod_zoomoodle\api(get_config('mod_zoomoodle', 'jwt_token'));
    $meeting = $api->get_meeting($moduleinstance->meeting_id);
    
    // Mostra i dettagli del meeting
    $meeting_info = html_writer::start_div('meeting-details');
    
    // Data e ora del meeting
    $meeting_info .= html_writer::tag('p', 
        get_string('meeting_time', 'zoomoodle') . ': ' . 
        userdate($meeting->start_time, get_string('strftimedatefullshort', 'core_langconfig'))
    );
    
    // Durata
    $meeting_info .= html_writer::tag('p',
        get_string('duration', 'zoomoodle') . ': ' .
        $meeting->duration . ' ' . get_string('minutes', 'zoomoodle')
    );
    
    // Link per partecipare
    if (has_capability('mod/zoomoodle:join', $modulecontext)) {
        $join_url = new moodle_url($meeting->join_url);
        $meeting_info .= html_writer::tag('p',
            html_writer::link(
                $join_url,
                get_string('join_meeting', 'zoomoodle'),
                array('class' => 'btn btn-primary', 'target' => '_blank')
            )
        );
    }
    
    $meeting_info .= html_writer::end_div();
    echo $meeting_info;
    
    // Mostra le statistiche di partecipazione per gli insegnanti
    if (has_capability('mod/zoomoodle:viewattendance', $modulecontext)) {
        $attendance_data = $DB->get_records('zoomoodle_attendance', 
            array('meeting_id' => $moduleinstance->meeting_id)
        );
        
        if (!empty($attendance_data)) {
            echo $OUTPUT->heading(get_string('attendance_stats', 'zoomoodle'), 3);
            
            $table = new html_table();
            $table->head = array(
                get_string('participant', 'zoomoodle'),
                get_string('duration', 'zoomoodle'),
                get_string('status', 'zoomoodle')
            );
            
            foreach ($attendance_data as $record) {
                $user = $DB->get_record('user', array('id' => $record->userid));
                if (!$user) {
                    continue;
                }
                
                $duration_minutes = round($record->duration);
                $status = $duration_minutes >= $moduleinstance->attendance_threshold ? 
                    get_string('present', 'zoomoodle') : 
                    get_string('absent', 'zoomoodle');
                
                $table->data[] = array(
                    fullname($user),
                    $duration_minutes . ' ' . get_string('minutes', 'zoomoodle'),
                    $status
                );
            }
            
            echo html_writer::table($table);
        }
    }
    
} catch (\Exception $e) {
    // Mostra un messaggio di errore appropriato
    echo $OUTPUT->notification(
        get_string('meeting_error', 'zoomoodle'),
        'error'
    );
}

// Mostra il footer della pagina
echo $OUTPUT->footer();

/**
 * Google Calendar button.
 */
function zoomoodle_view_google_calendar_button($course, $zoomoodle) {
    global $OUTPUT;
    $gcallink = new moodle_url('https://www.google.com/calendar/render', [
        'action' => 'TEMPLATE',
        'text'   => format_string($course->shortname) . ' - ' . format_string($zoomoodle->name),
        'dates'  => date('Ymd\\THi00\\Z', $zoomoodle->start_time)
                  . '/' . date('Ymd\\THi00\\Z', $zoomoodle->start_time + $zoomoodle->duration),
    ]);
    $icon   = $OUTPUT->pix_icon('i/calendar', get_string('calendariconalt', 'mod_zoomoodle'));
    $button = html_writer::span($icon . ' ' . get_string('calendaraddtogoogle', 'mod_zoomoodle'), 'btn btn-secondary');
    return html_writer::link($gcallink->out(false), $button, ['target' => '_blank']);
}

/**
 * Yahoo Calendar button.
 */
function zoomoodle_view_yahoo_calendar_button($course, $zoomoodle) {
    global $OUTPUT;
    $ycallink = new moodle_url('https://calendar.yahoo.com/', [
        'v'     => '60',
        'view'  => 'd',
        'type'  => '20',
        'title' => format_string($course->shortname) . ' - ' . format_string($zoomoodle->name),
        'st'    => date('Ymd\\THi00', $zoomoodle->start_time),
        'et'    => date('Ymd\\THi00', $zoomoodle->start_time + $zoomoodle->duration),
    ]);
    $icon   = $OUTPUT->pix_icon('i/calendar', get_string('calendariconalt', 'mod_zoomoodle'));
    $button = html_writer::span($icon . ' ' . get_string('calendaraddtoyahoo', 'mod_zoomoodle'), 'btn btn-secondary');
    return html_writer::link($ycallink->out(false), $button, ['target' => '_blank']);
}

/**
 * Outlook Calendar button.
 */
function zoomoodle_view_outlook_calendar_button($course, $zoomoodle) {
    global $OUTPUT;
    $ocallink = new moodle_url('https://outlook.live.com/owa/', [
        'path'     => '/calendar/view/Month',
        'rru'      => 'addevent',
        'dtstart'  => date('Ymd\\THi00\\Z', $zoomoodle->start_time),
        'dtend'    => date('Ymd\\THi00\\Z', $zoomoodle->start_time + $zoomoodle->duration),
        'summary'  => format_string($course->shortname) . ' - ' . format_string($zoomoodle->name),
    ]);
    $icon   = $OUTPUT->pix_icon('i/calendar', get_string('calendariconalt', 'mod_zoomoodle'));
    $button = html_writer::span($icon . ' ' . get_string('calendaraddtooutlook', 'mod_zoomoodle'), 'btn btn-secondary');
    return html_writer::link($ocallink->out(false), $button, ['target' => '_blank']);
}
