<?php
// This file is part of the Zoomoodle plugin for Moodle - http://moodle.org/
//
// Zoomoodle è free software: puoi ridistribuirlo e/o modificarlo
// secondo i termini della GNU General Public License come pubblicata
// dalla Free Software Foundation: versione 3 o successive.
// Zoomoodle viene distribuito nella speranza che sia utile,
// ma SENZA ALCUNA GARANZIA; senza neanche la garanzia implicita di
// PUBBLICA UTILITÀ. Per i dettagli, consulta la GNU GPL.
// Dovresti aver ricevuto una copia della GNU GPL insieme a Zoomoodle.
// Se non l'hai trovata, vai su <http://www.gnu.org/licenses/>.

namespace mod_zoomoodle;

defined('MOODLE_INTERNAL') || die();

global $CFG;
require_once($CFG->libdir . '/gradelib.php');
require_once($CFG->dirroot . '/grade/lib.php');
require_once($CFG->dirroot . '/mod/zoomoodle/lib.php');

use moodle_exception;
use coding_exception;
use context_course;

/**
 * Classe per la gestione della sincronizzazione dei dati tra Moodle e Zoom
 * 
 * Questa classe si occupa di gestire tutte le operazioni di sincronizzazione
 * tra Moodle e Zoom, inclusa la sincronizzazione dei meeting, dei partecipanti
 * e dei dati di presenza
 */
class sync_manager {
    /** @var \mod_zoomoodle\api Istanza della classe API */
    private $api;
    
    /** @var int Timestamp dell'ultima sincronizzazione */
    private $last_sync;
    
    /** @var array Cache dei dati sincronizzati */
    private static $sync_cache = array();

    /**
     * Costruttore della classe sync_manager
     * 
     * @throws \Exception se non è possibile inizializzare l'API
     */
    public function __construct() {
        $config = get_config('mod_zoomoodle');
        if (empty($config->jwt_token)) {
            throw new \Exception('Token JWT non configurato');
        }
        
        $this->api = new \mod_zoomoodle\api($config->jwt_token);
        $this->last_sync = get_config('mod_zoomoodle', 'last_sync_time');
    }

    /**
     * Esegue la sincronizzazione completa dei dati
     * 
     * @return bool true se la sincronizzazione è riuscita
     */
    public function sync_all() {
        try {
            // Sincronizza i meeting
            $this->sync_meetings();
            
            // Sincronizza i partecipanti
            $this->sync_participants();
            
            // Aggiorna il timestamp dell'ultima sincronizzazione
            set_config('last_sync_time', time(), 'mod_zoomoodle');
            
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Sincronizza i dati dei meeting da Zoom
     * 
     * @throws \Exception se si verificano errori durante la sincronizzazione
     */
    private function sync_meetings() {
        global $DB;
        
        // Recupera tutti i meeting attivi da Moodle
        $meetings = $DB->get_records('zoomoodle_meetings', ['active' => 1]);
        
        foreach ($meetings as $meeting) {
            try {
                // Recupera i dati aggiornati da Zoom
                $zoom_meeting = $this->api->get_meeting($meeting->meeting_id);
                
                // Aggiorna i dati nel database
                $meeting->topic = $zoom_meeting->topic;
                $meeting->start_time = strtotime($zoom_meeting->start_time);
                $meeting->duration = $zoom_meeting->duration;
                $meeting->timemodified = time();
                
                $DB->update_record('zoomoodle_meetings', $meeting);
                
            } catch (\Exception $e) {
                // Se il meeting non esiste più su Zoom, lo marca come inattivo
                if (strpos($e->getMessage(), 'Meeting not found') !== false) {
                    $meeting->active = 0;
                    $DB->update_record('zoomoodle_meetings', $meeting);
                }
            }
        }
    }

    /**
     * Sincronizza i dati dei partecipanti per tutti i meeting attivi
     * 
     * @throws \Exception se si verificano errori durante la sincronizzazione
     */
    private function sync_participants() {
        global $DB;
        
        // Recupera tutti i meeting attivi
        $meetings = $DB->get_records('zoomoodle_meetings', ['active' => 1]);
        
        foreach ($meetings as $meeting) {
            try {
                // Recupera i partecipanti da Zoom
                $participants = $this->api->get_meeting_participants($meeting->meeting_id);
                
                if (empty($participants)) {
                    continue;
                }
                
                // Elabora i dati di ogni partecipante
                foreach ($participants as $participant) {
                    $this->process_participant($meeting->meeting_id, $participant);
                }
                
            } catch (\Exception $e) {
                // Logga l'errore ma continua con il prossimo meeting
                mtrace('Errore nella sincronizzazione dei partecipanti per il meeting ' . 
                       $meeting->meeting_id . ': ' . $e->getMessage());
            }
        }
    }

    /**
     * Elabora i dati di un singolo partecipante
     * 
     * @param string $meeting_id ID del meeting
     * @param object $participant Dati del partecipante da Zoom
     */
    private function process_participant($meeting_id, $participant) {
        global $DB;
        
        // Cerca l'utente Moodle corrispondente
        $user = $DB->get_record('user', ['email' => $participant->user_email]);
        
        if (!$user) {
            return; // Utente non trovato nel sistema Moodle
        }
        
        // Calcola la durata della partecipazione
        $duration = ($participant->leave_time - $participant->join_time) / 60; // in minuti
        
        // Aggiorna o inserisce il record di partecipazione
        $record = new \stdClass();
        $record->meeting_id = $meeting_id;
        $record->userid = $user->id;
        $record->duration = $duration;
        $record->join_time = $participant->join_time;
        $record->leave_time = $participant->leave_time;
        $record->timemodified = time();
        
        if ($existing = $DB->get_record('zoomoodle_attendance', 
            ['meeting_id' => $meeting_id, 'userid' => $user->id])) {
            $record->id = $existing->id;
            $DB->update_record('zoomoodle_attendance', $record);
        } else {
            $DB->insert_record('zoomoodle_attendance', $record);
        }
        
        // Aggiorna il completamento del corso se necessario
        $this->update_course_completion($meeting_id, $user->id, $duration);
    }

    /**
     * Aggiorna il completamento del corso per un utente
     * 
     * @param string $meeting_id ID del meeting
     * @param int $userid ID dell'utente
     * @param float $duration Durata della partecipazione in minuti
     */
    private function update_course_completion($meeting_id, $userid, $duration) {
        global $DB;
        
        // Recupera il meeting e il modulo del corso
        $meeting = $DB->get_record('zoomoodle_meetings', ['meeting_id' => $meeting_id]);
        if (!$meeting) {
            return;
        }
        
        $cm = get_coursemodule_from_instance('zoomoodle', $meeting->id);
        if (!$cm) {
            return;
        }
        
        $course = $DB->get_record('course', ['id' => $cm->course]);
        if (!$course) {
            return;
        }
        
        // Calcola il punteggio in base alla durata
        $instance = $DB->get_record('zoomoodle', ['id' => $cm->instance]);
        if (!empty($instance->completion_on_duration)) {
            $threshold = $instance->completion_duration_minutes;
            $score = ($duration / $threshold) * 100;
            
            \mod_zoomoodle_update_completion($course, $cm, $userid, $score);
        }
    }

    /**
     * Pulisce la cache dei dati sincronizzati
     */
    public static function clear_cache() {
        self::$sync_cache = array();
    }

    /**
     * Ottiene un'istanza del lock factory per Zoomoodle
     * 
     * @return \core\lock\lock_factory|null
     */
    private static function get_lock_factory() {
        try {
            return \core\lock\lock_config::get_lock_factory('mod_zoomoodle');
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * Ottiene un lock per una risorsa
     * 
     * @param string $resource Nome della risorsa
     * @param int $timeout Timeout in secondi
     * @return \core\lock\lock|false
     */
    private static function get_lock($resource, $timeout) {
        $factory = self::get_lock_factory();
        if (!$factory) {
            return false;
        }
        return $factory->get_lock($resource, $timeout);
    }

    /**
     * Rilascia un lock
     * 
     * @param \core\lock\lock $lock Lock da rilasciare
     * @return bool
     */
    private static function release_lock($lock) {
        if ($lock) {
            return $lock->release();
        }
        return false;
    }

    /**
     * Metodo principale per l'esecuzione della sincronizzazione
     * Implementa il pattern Singleton per evitare sincronizzazioni multiple
     * 
     * @return bool true se la sincronizzazione è completata con successo
     */
    public static function run() {
        // Ottieni un lock per la sincronizzazione
        $lock = self::get_lock('mod_zoomoodle_sync', 10);
        if (!$lock) {
            mtrace('Impossibile ottenere il lock per la sincronizzazione');
            return false;
        }

        try {
            $instance = new self();
            $result = $instance->sync_all();
            
            if ($result) {
                mtrace('Sincronizzazione completata con successo');
            } else {
                mtrace('Errore durante la sincronizzazione');
            }
            
            return $result;
            
        } catch (\Exception $e) {
            mtrace('Errore critico durante la sincronizzazione: ' . $e->getMessage());
            return false;
            
        } finally {
            // Rilascia sempre il lock
            self::release_lock($lock);
        }
    }
}
