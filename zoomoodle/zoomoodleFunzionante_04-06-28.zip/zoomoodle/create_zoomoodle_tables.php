<?php
require_once(__DIR__ . '/../../config.php');

// Verifica che l'utente sia admin
require_login();
if (!is_siteadmin()) {
    die("Accesso negato");
}

$DB->execute("
    CREATE TABLE IF NOT EXISTS {zoomoodle_participants} (
        id BIGINT(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
        zoomid BIGINT(10) NOT NULL,
        userid BIGINT(10) NOT NULL,
        duration BIGINT(10) NOT NULL DEFAULT 0,
        joinedat BIGINT(10),
        leftat BIGINT(10)
    )
");

echo "✅ Tabella zoomoodle_participants creata o già esistente.<br>";

$DB->execute("
    CREATE TABLE IF NOT EXISTS {zoomoodle_userdata} (
        id BIGINT(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
        zoomid BIGINT(10) NOT NULL,
        userid BIGINT(10) NOT NULL,
        votogrezzo DOUBLE DEFAULT NULL,
        votopercentuale DOUBLE DEFAULT NULL
    )
");

echo "✅ Tabella zoomoodle_userdata creata o già esistente.<br>";
echo "🎉 Operazione completata.";
?>
