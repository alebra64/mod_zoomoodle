<?php
// Configurazione iniziale
define('AJAX_SCRIPT', true);
define('NO_OUTPUT_BUFFERING', true);
define('NO_MOODLE_COOKIES', true);
define('NO_UPGRADE_CHECK', true);

// Debug base - no HTML
header('Content-Type: text/plain');

// Forza visualizzazione errori
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
ini_set('html_errors', 0);
error_reporting(E_ALL);

function debug($message) {
    echo "DEBUG: " . $message . "\n";
}

debug("1: Script iniziato");
debug("2: Definite funzioni base");

// Percorso Moodle
$moodleRoot = dirname(dirname(dirname(dirname(__FILE__))));
debug("3: Moodle root = " . $moodleRoot);

// Prima carichiamo config.php
debug("4: Tentativo caricamento config.php");
require_once($moodleRoot . '/config.php');
debug("5: config.php caricato con successo");

// Verifica e carica le dipendenze di completion
$dependencies = [
    '/completion/completion_aggregation.php',
    '/completion/criteria/completion_criteria.php',
    '/completion/completion_completion.php',
    '/completion/completion_criteria_completion.php',
    '/lib/gradelib.php'
];

debug("6: Caricamento dipendenze completion");
foreach ($dependencies as $dep) {
    $fullPath = $CFG->dirroot . $dep;
    if (file_exists($fullPath)) {
        debug("Caricamento: " . basename($fullPath));
        require_once($fullPath);
    } else {
        debug("ATTENZIONE: Dipendenza non trovata: " . $fullPath);
    }
}

// Ora proviamo a caricare completionlib.php
$completionPath = $CFG->dirroot . '/lib/completionlib.php';
debug("7: Tentativo caricamento completionlib.php");

try {
    require_once($completionPath);
    debug("8: completionlib.php caricato con successo");
    
    if (class_exists('completion_info')) {
        debug("9: Classe completion_info trovata");
        $methods = get_class_methods('completion_info');
        debug("10: Metodi disponibili (" . count($methods) . "):");
        foreach ($methods as $method) {
            debug("- " . $method);
        }
    } else {
        debug("9-ERR: Classe completion_info non trovata");
        debug("10: Classi disponibili relative a completion:");
        foreach (get_declared_classes() as $class) {
            if (stripos($class, 'completion') !== false) {
                debug("- " . $class);
            }
        }
    }
} catch (Exception $e) {
    debug("ERR nel caricamento: " . $e->getMessage());
    debug("Stack trace: " . $e->getTraceAsString());
}

debug("FINE: Script completato"); 