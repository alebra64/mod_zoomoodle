<?php

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/gradelib.php');

// Definizione dei parametri di debug
$debug = optional_param('debug', 0, PARAM_INT);

// Inizializza il contesto di sistema per i permessi
require_login();
$context = context_system::instance();
require_capability('moodle/site:config', $context);

header('Content-Type: text/plain; charset=utf-8');
echo "Avvio aggiornamento valori in tabella zoomoodle_userdata...\n";

// Ottieni tutti i moduli Zoomoodle con valutazione associata
$sql = "
    SELECT cm.id as cmid, cm.course, m.id as instanceid, m.name
    FROM {course_modules} cm
    JOIN {modules} mo ON mo.id = cm.module
    JOIN {zoomoodle} m ON m.id = cm.instance
    JOIN {grade_items} gi ON gi.iteminstance = m.id AND gi.itemmodule = 'zoomoodle'
    WHERE mo.name = 'zoomoodle'
";

$modules = $DB->get_records_sql($sql);
$total = 0;

foreach ($modules as $mod) {
    $cmid = $mod->cmid;
    $courseid = $mod->course;
    $instanceid = $mod->instanceid;

    $grades = grade_get_grades($courseid, 'mod', 'zoomoodle', $instanceid);

    if ($debug) {
        echo "\nMod: $mod->name (instance: $instanceid, course: $courseid, cmid: $cmid)\n";
        echo "Trovati voti: " . count($grades->items[0]->grades) . "\n";
    }

    if (empty($grades->items) || empty($grades->items[0]->grades)) {
        if ($debug) echo " - Nessun voto trovato.\n";
        continue;
    }

    foreach ($grades->items[0]->grades as $userid => $gradeinfo) {
        if ($gradeinfo->grade === null) {
            if ($debug) echo "   - Utente $userid ha voto nullo, ignorato.\n";
            continue;
        }

        $record = $DB->get_record('zoomoodle_userdata', [
            'userid' => $userid,
            'zoomoodleid' => $instanceid
        ]);

        $data = new stdClass();
        $data->userid = $userid;
        $data->zoomoodleid = $instanceid;
        $data->webinarid = 0;
        $data->totalseconds = 300;
        $data->thresholdseconds = 150;

        if ($record) {
            $data->id = $record->id;
            $DB->update_record('zoomoodle_userdata', $data);
            $total++;
            if ($debug) echo "   - Utente $userid aggiornato (record ID: $record->id)\n";
        } else {
            $DB->insert_record('zoomoodle_userdata', $data);
            $total++;
            if ($debug) echo "   - Utente $userid inserito (nuovo record)\n";
        }
    }
}

echo "\nAggiornamento completato. Record modificati o creati: $total\n";
