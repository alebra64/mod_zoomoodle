<?php
require_once(__DIR__ . '/../../config.php');
require_login();
if (!is_siteadmin()) {
    die("Accesso negato");
}

echo "<h2>Verifica tabelle Zoomoodle</h2>";

$tables = ['zoomoodle', 'zoomoodle_userdata', 'zoomoodle_participants'];
foreach ($tables as $table) {
    echo "<h3>Contenuto della tabella: {$table}</h3>";
    try {
        $records = $DB->get_records($table);
        if (empty($records)) {
            echo "<p style='color:orange'>⚠️ Nessun record trovato.</p>";
        } else {
            echo "<table border='1' cellpadding='5'><tr>";
            $first = reset($records);
            foreach ($first as $field => $value) {
                echo "<th>{$field}</th>";
            }
            echo "</tr>";
            foreach ($records as $record) {
                echo "<tr>";
                foreach ($record as $value) {
                    echo "<td>" . htmlspecialchars($value) . "</td>";
                }
                echo "</tr>";
            }
            echo "</table>";
        }
    } catch (dml_exception $e) {
        echo "<p style='color:red'>❌ Errore: la tabella '{$table}' non esiste.</p>";
    }
}
?>
