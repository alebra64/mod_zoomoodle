<?php
// File: mod/zoomoodle/grade_debug.php
// Debug di gradepass e decimals per gli item Zoomoodle.

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir   . '/gradelib.php');
require_once($CFG->dirroot . '/mod/zoomoodle/lib.php');

// Course ID from URL
$courseid = optional_param('course', 0, PARAM_INT);
if (!$courseid) {
    die("Errore: specifica l'id del corso via ?course=ID");
}
require_login();
if (!is_siteadmin()) {
    die("Accesso negato");
}

global $DB;

echo "<h2>Grade Item Debug – Corso $courseid</h2>";
echo "<ul>";

// Prendi tutte le istanze Zoomoodle di questo corso
$instances = $DB->get_records('zoomoodle', ['course' => $courseid]);
foreach ($instances as $instance) {
    // recupera il grade_item
    $gi = grade_item::fetch([
        'itemtype'     => 'mod',
        'itemmodule'   => 'zoomoodle',
        'iteminstance' => $instance->id,
        'courseid'     => $courseid
    ]);
    if (!$gi) {
        echo "<li>Istanza {$instance->id}: <strong>NESSUN grade_item</strong></li>";
        continue;
    }
    // leggi dal DB i campi gradepass e decimals
    $gp = $DB->get_field('grade_items', 'gradepass', ['id' => $gi->id]);
    $dc = $DB->get_field('grade_items', 'decimals',  ['id' => $gi->id]);
    echo "<li>Istanza {$instance->id}: grade_item id={$gi->id}, gradepass={$gp}, decimals={$dc}</li>";
}

echo "</ul><p><em>Fine debug.</em></p>";
