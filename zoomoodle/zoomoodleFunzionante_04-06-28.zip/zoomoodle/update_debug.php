<?php
// File: mod/zoomoodle/update_debug.php
// Semplificato: debug solo percentuali e decimali

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/gradelib.php');
require_once($CFG->dirroot . '/mod/zoomoodle/lib.php');

$courseid = optional_param('course', 0, PARAM_INT);
if (!$courseid) {
    die("Errore: specifica l'id del corso ?course=ID");
}
require_login();
if (!is_siteadmin()) {
    die("Accesso negato");
}

echo "<h2>DEBUG Zoomoodle</h2>";
echo "Corso ID: {$courseid}<br><br>";

// 1) Trova tutte le istanze del corso
$instances = $DB->get_records('zoomoodle', ['course' => $courseid]);
echo "Trovate " . count($instances) . " istanze Zoomoodle<br><br>";

foreach ($instances as $instance) {
    echo "<hr>";
    echo "<strong>Istanza ID:</strong> {$instance->id} — totalseconds: {$instance->totalseconds}<br>";

    // 2) Quanti utenti
    $cm = get_coursemodule_from_instance('zoomoodle', $instance->id, $courseid);
    if (!$cm) {
        echo "CM non trovato<br>";
        continue;
    }
    $context = context_module::instance($cm->id);
    $users   = get_enrolled_users($context);
    echo "Utenti iscritti: " . count($users) . "<br>";

    // 3) Il grade_item
    $gradeitem = grade_item::fetch([
        'itemtype'     => 'mod',
        'itemmodule'   => 'zoomoodle',
        'iteminstance' => $instance->id,
        'courseid'     => $courseid
    ]);
    if (!$gradeitem) {
        echo "Grade_item non trovato<br>";
        continue;
    }

    // 4) Decimali prima / dopo
    $decbefore = $DB->get_field('grade_items', 'decimals', ['id' => $gradeitem->id]);
    echo "Decimali prima: {$decbefore}<br>";
    // forza 2 decimali a livello di record
    $DB->set_field('grade_items', 'decimals', 2, ['id' => $gradeitem->id]);
    $decafter = $DB->get_field('grade_items', 'decimals', ['id' => $gradeitem->id]);
    echo "Decimali dopo: {$decafter}<br>";

    // 5) Percentuali utente per utente
    $threshold = (float)$instance->attendance_threshold;
    echo "Soglia impostata: {$threshold}%<br><br>";

    foreach ($users as $user) {
        $record = $DB->get_record('zoomoodle_participants', [
            'zoomid' => $instance->id,
            'userid' => $user->id
        ]);
        $duration = $record ? $record->duration : 0;
        if (!$record || empty($instance->totalseconds)) {
            echo "User {$user->id}: nessun record o totalseconds mancante → skip<br>";
            continue;
        }
        $percent = round($duration / $instance->totalseconds * 100, 2);
        echo "User {$user->id}: duration={$duration}s → percent={$percent}% ";
        echo ($percent >= $threshold) 
            ? "(>= soglia, ok)<br>" 
            : "(< soglia, ko)<br>";
    }
}

echo "<br><em>Fine debug.</em>";
