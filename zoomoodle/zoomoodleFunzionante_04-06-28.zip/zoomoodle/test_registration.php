<?php
require_once(__DIR__ . '/../../config.php');
require_once($CFG->dirroot . '/mod/zoomoodle/lib.php');

// Protezione accesso
require_login();
if (!is_siteadmin()) {
    die("Accesso negato - Solo gli amministratori possono eseguire questo script");
}

echo "<h2>Test Registrazione Webinar Zoom</h2>";

$courseid = optional_param('courseid', 0, PARAM_INT);
$userid = optional_param('userid', 0, PARAM_INT);

if (!$courseid || !$userid) {
    die("Specifica courseid e userid nell'URL: test_registration.php?courseid=XXX&userid=YYY");
}

// Simula l'evento di iscrizione
$enrol = new stdClass();
$enrol->courseid = $courseid;
$enrol->userid = $userid;

echo "<h3>Dettagli Test</h3>";
echo "Corso ID: {$courseid}<br>";
echo "Utente ID: {$userid}<br>";

// Esegui la registrazione
try {
    zoomoodle_user_enrolled($enrol);
    echo "<p style='color: green;'>Test completato. Controlla i log di debug per i dettagli.</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>Errore durante il test: " . $e->getMessage() . "</p>";
}

// Mostra registrazioni esistenti
echo "<h3>Registrazioni Esistenti</h3>";
$registrations = $DB->get_records('zoomoodle_registrants', ['userid' => $userid]);

if ($registrations) {
    echo "<ul>";
    foreach ($registrations as $reg) {
        $instance = $DB->get_record('zoomoodle', ['id' => $reg->zoomid]);
        echo "<li>Webinar: {$instance->name} (ID: {$instance->webinar_id})<br>";
        echo "Registrant ID: {$reg->registrant_id}<br>";
        echo "Data registrazione: " . userdate($reg->timecreated) . "</li>";
    }
    echo "</ul>";
} else {
    echo "<p>Nessuna registrazione trovata per questo utente.</p>";
} 