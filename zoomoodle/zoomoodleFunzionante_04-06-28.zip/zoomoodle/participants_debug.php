<?php
// File: mod/zoomoodle/participants_debug.php
// Elenca i valori raw della tabella zoomoodle_participants.

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir   . '/gradelib.php'); // non strettamente necessario
require_once($CFG->dirroot . '/mod/zoomoodle/lib.php');

$instanceid = optional_param('instance', 0, PARAM_INT);
if (!$instanceid) {
    die("Errore: specifica l'id dell'istanza via ?instance=ID");
}
require_login();
if (!is_siteadmin()) {
    die("Accesso negato");
}

echo "<h2>Debug zoomoodle_participants – Istanza {$instanceid}</h2>";
echo "<table border='1' cellpadding='5'>
        <tr>
          <th>userid</th>
          <th>joinedat (ts)</th>
          <th>joinedat (h:i:s)</th>
          <th>leftat (ts)</th>
          <th>leftat (h:i:s)</th>
          <th>duration (s)</th>
        </tr>";

$records = $DB->get_records('zoomoodle_participants', ['zoomid' => $instanceid]);
foreach ($records as $r) {
    $ja = (int)$r->joinedat;
    $la = (int)$r->leftat;
    echo "<tr>
            <td>{$r->userid}</td>
            <td>{$ja}</td>
            <td>" . ($ja ? date('H:i:s', $ja) : '-') . "</td>
            <td>{$la}</td>
            <td>" . ($la ? date('H:i:s', $la) : '-') . "</td>
            <td>{$r->duration}</td>
          </tr>";
}
echo "</table><p><em>Fine debug.</em></p>";
