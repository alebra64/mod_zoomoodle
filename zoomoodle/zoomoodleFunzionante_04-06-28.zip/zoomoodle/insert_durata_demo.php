<?php
require_once(__DIR__ . '/../../config.php');
require_login();
if (!is_siteadmin()) {
    die("Accesso negato");
}

global $DB;

// Parametri
$zoomid = 160;
$durate = [
    9521 => 180,   // Luca Iacopozzi
    2600 => 120,   // Concetta Mormina
    12461 => 240,  // Amilcare Ponchielli
    3628 => 0      // Utente Prova (nessuna durata)
];

echo "Inserimento durate nella tabella zoomoodle_participants per ZoomID {$zoomid}...<br><br>";
$inseriti = 0;
$aggiornati = 0;

foreach ($durate as $userid => $duration) {
    $esiste = $DB->get_record('zoomoodle_participants', ['zoomid' => $zoomid, 'userid' => $userid]);
    if ($esiste) {
        $esiste->duration = $duration;
        $DB->update_record('zoomoodle_participants', $esiste);
        echo "🔁 Utente {$userid}: record aggiornato con durata {$duration} secondi.<br>";
        $aggiornati++;
    } else {
        $DB->insert_record('zoomoodle_participants', [
            'zoomid' => $zoomid,
            'userid' => $userid,
            'duration' => $duration
        ]);
        echo "✅ Utente {$userid}: nuovo record inserito con durata {$duration} secondi.<br>";
        $inseriti++;
    }
}

echo "<br>Totale nuovi record inseriti: {$inseriti}<br>";
echo "Totale record aggiornati: {$aggiornati}<br>";
?>
