<?php
// File: mod/zoomoodle/completion_state_debug.php
// Debug degli stati di completamento attività per Zoomoodle.
// Aggiornato per Moodle 3.8, rimosso l’uso di get_settings()

require_once(__DIR__ . '/../../config.php');
require_once($CFG->dirroot . '/course/lib.php');        // per get_course()
require_once($CFG->libdir   . '/completionlib.php');    // per completion_info
require_once($CFG->dirroot . '/mod/zoomoodle/lib.php'); // eventuali funzioni di Zoomoodle

// Recupera course ID da URL
$courseid = optional_param('course', 0, PARAM_INT);
if (!$courseid) {
    die("Errore: specifica l'id del corso via ?course=ID");
}
require_login();
if (!is_siteadmin()) {
    die("Accesso negato");
}
$course = get_course($courseid);

echo "<h2>Completion State Debug – Corso {$courseid}</h2>";
echo "<ul>";

// Inizializza engine completion
$completion = new completion_info($course);

// Prendi tutte le istanze Zoomoodle di questo corso
global $DB;
$instances = $DB->get_records('zoomoodle', ['course' => $courseid]);

foreach ($instances as $instance) {
    // Recupera il course module per l'istanza Zoomoodle
    $cm = get_coursemodule_from_instance('zoomoodle', $instance->id, $courseid);
    if (!$cm) {
        echo "<li>Istanza {$instance->id}: CM non trovato</li>";
        continue;
    }

    // Controlla se il completion è abilitato per questo modulo
    $enabled = $completion->is_enabled($cm) ? 'sì' : 'no';

    echo "<li>Istanza {$instance->id}: completion enabled = {$enabled}</li>";

    // Esegui una query diretta per vedere lo stato in course_modules_completion
    $sql = "
        SELECT
            u.id       AS userid,
            u.email,
            cmc.completionstate AS state
          FROM {user} u
    LEFT JOIN {course_modules_completion} cmc
           ON cmc.userid       = u.id
          AND cmc.coursemoduleid = :cmid
         WHERE u.deleted = 0
    ";
    $records = $DB->get_records_sql($sql, ['cmid' => $cm->id]);
    $count   = count($records);

    if ($count > 1) {
        echo "<li>Istanza {$instance->id}: trovati {$count} record in course_modules_completion (usiamo il primo)</li>";
    } else {
        echo "<li>Istanza {$instance->id}: trovati {$count} record in course_modules_completion</li>";
    }

    if ($count > 0) {
        echo "<li>Dettaglio completionstate (0=non completato, 1=completato manualmente, 2=completato automaticamente):<ul>";
        $first = true;
        foreach ($records as $r) {
            echo "<li>Utente ID={$r->userid}, email={$r->email}, state={$r->state}</li>";
            if ($first) {
                // commenta la riga seguente se vuoi vedere tutti i record
                // break;
                $first = false;
            }
        }
        echo "</ul></li>";
    }
}

echo "</ul><p><em>Fine debug.</em></p>";
