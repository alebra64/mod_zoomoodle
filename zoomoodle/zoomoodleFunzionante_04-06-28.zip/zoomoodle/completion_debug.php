<?php
// File: mod/zoomoodle/completion_debug.php
// Debug delle impostazioni di activity completion per Zoomoodle.
// Compatibile con Moodle 3.8 anche in presenza di record duplicati.

require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir   . '/completionlib.php');
require_once($CFG->dirroot . '/mod/zoomoodle/lib.php');

$courseid = optional_param('course', 0, PARAM_INT);
if (!$courseid) {
    die("Errore: specifica l'id del corso via ?course=ID");
}
require_login();
if (!is_siteadmin()) {
    die("Accesso negato");
}

$course = get_course($courseid);
echo "<h2>Activity Completion Debug – Corso {$courseid}</h2>";
echo "<ul>";

global $DB;

// Prendi tutte le istanze Zoomoodle di questo corso
$instances = $DB->get_records('zoomoodle', ['course' => $courseid]);
foreach ($instances as $instance) {
    $cm = get_coursemodule_from_instance('zoomoodle', $instance->id, $courseid);
    if (!$cm) {
        echo "<li>Istanza {$instance->id}: CM non trovato</li>";
        continue;
    }

    // Recupera eventuali record di course_modules_completion
    $allrecords = $DB->get_records('course_modules_completion', ['coursemoduleid' => $cm->id]);
    if (empty($allrecords)) {
        // Nessun record = activity completion NON abilitata
        echo "<li>Istanza {$instance->id}: enabled=no (nessun record in course_modules_completion)</li>";
        continue;
    }

    // Se ci sono più record, segnaliamo la situazione e prendiamo il primo.
    if (count($allrecords) > 1) {
        echo "<li>Istanza {$instance->id}: trovati " . count($allrecords) .
             " record in course_modules_completion (usiamo il primo)</li>";
    }

    // Prendiamo il primo record
    $cmcompletion = reset($allrecords);

    // L’activity completion è abilitata
    $cond = [];
    $cond[] = 'enabled=sì';

    // Leggi requiregrade e gradepass dal primo record
    if (!empty($cmcompletion->requiregrade)) {
        $cond[] = 'requiregrade=1';
        $cond[] = 'gradepass=' . (float)$cmcompletion->gradepass;
    } else {
        $cond[] = 'requiregrade=0';
    }

    echo "<li>Istanza {$instance->id}: " . implode(', ', $cond) . "</li>";
}

echo "</ul><p><em>Fine debug.</em></p>";

