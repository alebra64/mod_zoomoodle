<?php
require_once(__DIR__ . '/../../config.php');
require_login();
if (!is_siteadmin()) {
    die("Accesso negato");
}

$zoomid = 160;

echo "<h3>Contenuto tabella zoomoodle_participants per ZoomID {$zoomid}</h3>";
$records = $DB->get_records('zoomoodle_participants', ['zoomid' => $zoomid]);

if (!$records) {
    echo "⚠️ Nessun record trovato per zoomid={$zoomid}";
} else {
    echo "<table border='1' cellpadding='4' cellspacing='0'>";
    echo "<tr><th>UserID</th><th>ZoomID</th><th>Duration</th><th>Joins</th><th>Leave Time</th><th>Join Time</th><th>Altri Campi</th></tr>";
    foreach ($records as $r) {
        echo "<tr>";
        echo "<td>{$r->userid}</td>";
        echo "<td>{$r->zoomid}</td>";
        echo "<td>{$r->duration}</td>";
        echo "<td>{$r->join_count}</td>";
        echo "<td>{$r->leave_time}</td>";
        echo "<td>{$r->join_time}</td>";
        echo "<td>" . json_encode($r) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}
?>
