<?php
// File: debug_zoomoodle_grades.php
// Scopo: Diagnostica della lettura durate reali da Zoom

require_once(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/classes/api.php');

use mod_zoomoodle\api;

require_login();
if (!is_siteadmin()) {
    die("Accesso negato");
}

global $DB;

echo "<h3>Diagnostica Zoomoodle: Durate reali dai webinar</h3>";

$instances = $DB->get_records('zoomoodle', ['enablesync' => 1]);

foreach ($instances as $instance) {
    $webinarid = trim($instance->webinarid);
    $zoomoodleid = $instance->id;

    if (!ctype_digit($webinarid)) {
        echo "<p>⚠️ Webinar ID non valido per Zoomoodle ID {$zoomoodleid}: '{$webinarid}'</p>";
        continue;
    }

    echo "<h4>📘 Zoomoodle ID {$zoomoodleid}, Webinar ID {$webinarid}</h4>";

    $participants = api::get_webinar_participants((int)$webinarid);

    if (!$participants || !is_array($participants)) {
        echo "<p>❌ Nessun partecipante recuperato</p>";
        continue;
    }

    echo "<table border='1' cellpadding='4'>";
    echo "<tr><th>User ID</th><th>Nome</th><th>Email</th><th>Durata (s)</th><th>Join time</th><th>Leave time</th></tr>";

    foreach ($participants as $p) {
        $uid = $p['user_id'] ?? '-';
        $name = htmlspecialchars($p['name'] ?? '-');
        $email = htmlspecialchars($p['user_email'] ?? '-');
        $duration = $p['duration'] ?? 0;
        $join = $p['join_time'] ?? '-';
        $leave = $p['leave_time'] ?? '-';
        echo "<tr><td>{$uid}</td><td>{$name}</td><td>{$email}</td><td>{$duration}</td><td>{$join}</td><td>{$leave}</td></tr>";
    }

    echo "</table><br>";
}
?>
